/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aabujwei <aabujwei@learner.42.tech>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 14:17:58 by aabujwei          #+#    #+#             */
/*   Updated: 2025/09/14 14:18:38 by aabujwei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_combn_recursive(char *comb, int n, int p)
{
	char	num;

	if (p == n)
	{
		write(1, comb, n);
		if (comb[0] != '0' + 10 - n)
			write(1, ", ", 2);
		return ;
	}
	if (p == 0)
		num = '0';
	else
		num = comb[p - 1] + 1;
	while (num <= '9')
	{
		comb[p] = num;
		ft_print_combn_recursive(comb, n, p + 1);
		num++;
	}
}

void	ft_print_combn(int n)
{
	char	comb[9];

	if (n <= 0 || n >= 10)
		return ;
	ft_print_combn_recursive(comb, n, 0);
}
